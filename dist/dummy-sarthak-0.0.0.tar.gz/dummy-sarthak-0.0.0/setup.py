from setuptools import setup

setup(name='dummy-sarthak',
      version='0.0.0',
      description='First library',
      author_email='sarthak.anand@h2o.ai',
      url='https://github.com/isarth23/dummy',
)
