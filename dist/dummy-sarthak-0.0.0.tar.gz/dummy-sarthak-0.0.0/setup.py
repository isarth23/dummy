from setuptools import setup

setup(name='dummy-sarthak',
      version='0.0.0',
      description='First library',
      author_email='isarth@me.com'
)
